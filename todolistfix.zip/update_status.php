<?php
include 'koneksi.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

// Validasi input
if (!isset($_POST['id']) || !isset($_POST['status'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit;
}

$task_id = $_POST['id'];
$new_status = $_POST['status'];

if ($new_status == 'Selesai') {
    // Ambil data task
    $stmt = mysqli_prepare($conn_todolist, "SELECT * FROM tasks WHERE id=?");
    mysqli_stmt_bind_param($stmt, "i", $task_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $task = mysqli_fetch_assoc($result);

    if ($task) {
        // Masukkan ke tabel completed_task
        $stmt_insert = mysqli_prepare($conn_todolist, 
            "INSERT INTO completed_task (task_id, nama_tugas, deadline, prioritas, status) VALUES (?, ?, ?, ?, ?)"
        );
        mysqli_stmt_bind_param($stmt_insert, "issss", $task_id, $task['nama_tugas'], $task['deadline'], $task['prioritas'], $new_status);
        $insert_success = mysqli_stmt_execute($stmt_insert);

        if ($insert_success) {
            // Hapus dari tabel tasks
            $stmt_delete = mysqli_prepare($conn_todolist, "DELETE FROM tasks WHERE id=?");
            mysqli_stmt_bind_param($stmt_delete, "i", $task_id);
            $delete_success = mysqli_stmt_execute($stmt_delete);

            if ($delete_success) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Gagal menghapus task']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Gagal menyimpan riwayat task']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Task tidak ditemukan']);
    }
} else {
    // Update status saja jika bukan ke "Selesai"
    $stmt_update = mysqli_prepare($conn_todolist, "UPDATE tasks SET status=? WHERE id=?");
    mysqli_stmt_bind_param($stmt_update, "si", $new_status, $task_id);
    $update_success = mysqli_stmt_execute($stmt_update);

    if ($update_success) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal mengupdate status']);
    }
}
?>
